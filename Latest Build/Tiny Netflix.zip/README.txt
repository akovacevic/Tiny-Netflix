# Tiny-Netflix
A program that allows Netflix to be viewed in a tiny window at the side of the screen.

Current Version: v1.0

Requires Internet Explorer to be installed as this program acts as a shell for it.

Also netflix requires silverlight to be installed to watch videos (it will prompt you to install it automatically if you try to play a video).

Controls:

Alt+Q : Quit Application whether it is minimized or not.
Alt+X : Hide/Show player while its playing. Also can be used to minimize while browsing.
Ctrl+1 / Ctrl+2 : Scale the player while a video is playing (Application must have focus for theis).
Escape: Quit Application when you actually have it selected.


Known Issues:
- Internet explorer sucks and makes the login page look horrible and the video catagories cannot be scrolled horizontally (Searching works though). Working on finding a better browser plugin.